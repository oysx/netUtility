#!/bin/bash

diff  -Naur  libnids-1.21 libnids-1.21_patched >justniffer.patch
