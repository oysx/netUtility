/* FTP extension for connection tracking. */

/* (C) 1999-2001 Paul `Rusty' Russell
 * (C) 2002-2004 Netfilter Core Team <coreteam@netfilter.org>
 * (C) 2003,2004 USAGI/WIDE Project <http://www.linux-ipv6.org>
 * (C) 2006-2012 Patrick McHardy <kaber@trash.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 */

#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/netfilter.h>
#include <linux/ip.h>
#include <linux/slab.h>
#include <linux/ctype.h>
#include <linux/inet.h>
#include <net/checksum.h>
#include <net/tcp.h>
#include <linux/atomic.h>

#include <linux/file.h>
#include <linux/fs.h>
#include <linux/proc_fs.h>
#include <linux/seq_file.h>

#include <net/netfilter/nf_conntrack.h>
#include <net/netfilter/nf_conntrack_helper.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Rusty Russell <rusty@rustcorp.com.au>");
MODULE_DESCRIPTION("http-rtt connection tracking helper");
MODULE_ALIAS("ip_conntrack_httprtt");
MODULE_ALIAS_NFCT_HELPER("httprtt");

typedef typeof(jiffies_64) ts64;

struct nf_ct_httprtt_master {
	ts64 timestamp;
	ulong done;
	ulong count;
};

static ushort conf_port=8000;
static ulong conf_threshold=HZ/10;
static atomic_t result_counter[3]={ATOMIC_INIT(0),ATOMIC_INIT(0),ATOMIC_INIT(0)};
module_param(conf_port, ushort, 0600);
module_param(conf_threshold, ulong, 0600);

static void maximum(int val, atomic_t *max) {
	int old, to=10, ret;
	old = atomic_read(max);
	if (val > old) {
		while(--to) {
			ret = atomic_cmpxchg(max, old, val);
			if (ret == old) return;
		}
		printk(KERN_ERR "busy for setting maximum!\n");
	}
}

static void statistic(ts64 rtt) {
	if (rtt >= conf_threshold) {
		atomic_inc(&result_counter[0]);
	}
	atomic_inc(&result_counter[1]);
	maximum((int)rtt, &result_counter[2]);
	printk(KERN_ERR "TTFB:%d\n", (int)rtt);
}

static int help(struct sk_buff *skb,
		unsigned int protoff,
		struct nf_conn *ct,
		enum ip_conntrack_info ctinfo)
{
#define ICSK(skb, field) skb->sk?(inet_csk(skb->sk)->field):255
#define TP(skb, field, def) skb->sk?(tcp_sk(skb->sk)->field):def
#define FORMAT "%d->%d, FIN=%d, RST=%d, rto=%d, state=%d, ca=%d, reTS=%d, rtt=%d, bkoff=%d, prbout=%d, retrans=%d, pktfly=%d, cwnd=%d, pcount=%d, "
#define DATA sport, dport, th->fin, th->rst, skb->sk?jiffies_to_usecs(inet_csk(skb->sk)->icsk_rto)/1000:0, skb->sk?skb->sk->sk_state:255, skb->sk?inet_csk(skb->sk)->icsk_ca_state:255, skb->sk?jiffies_to_usecs(tcp_sk(skb->sk)->retrans_stamp):0, skb->sk?jiffies_to_usecs(tcp_sk(skb->sk)->srtt)/1000:0, skb->sk?inet_csk(skb->sk)->icsk_backoff:255, ICSK(skb, icsk_probes_out), ICSK(skb, icsk_retransmits), TP(skb, packets_out, 0), TP(skb, snd_cwnd, 255), tcp_skb_pcount(skb) 
//#define FORMAT "httprtt: %d->%d, SYN=%d, ACK=%d, FIN=%d, RST=%d, PUSH=%d, seq=%u, ack_seq=%u, skb=0x%p, rto=%d, state=%d, ca=%d, reTS=%d, "
//#define DATA sport, dport, th->syn, th->ack, th->fin, th->rst, th->psh, ntohl(th->seq), ntohl(th->ack_seq), (void*)skb, skb->sk?jiffies_to_usecs(inet_csk(skb->sk)->icsk_rto):0, skb->sk?skb->sk->sk_state:255, skb->sk?inet_csk(skb->sk)->icsk_ca_state:255, skb->sk?jiffies_to_usecs(tcp_sk(skb->sk)->retrans_stamp):0

	char *type=0;
	unsigned int dataoff, datalen;
	const struct tcphdr *th;
	struct tcphdr _tcph;
	int ret=NF_ACCEPT;
	ushort dport,sport;
	ts64 delta;
	int dir = CTINFO2DIR(ctinfo);
	struct nf_ct_httprtt_master *ct_httprtt_info = nfct_help_data(ct);

	//printk(KERN_ERR "httprtt %d\n", ctinfo);
	/* Until there's been traffic both ways, don't look in packets. */
	if (ctinfo != IP_CT_ESTABLISHED &&
	    ctinfo != IP_CT_ESTABLISHED_REPLY) {
		printk(KERN_ERR "httprt: Conntrackinfo = %u\n", ctinfo);
		return NF_ACCEPT;
	}

	th = skb_header_pointer(skb, protoff, sizeof(_tcph), &_tcph);
	if (th == NULL)
		return NF_ACCEPT;

	dataoff = protoff + th->doff * 4;

	sport = ntohs(ct->tuplehash[dir].tuple.src.u.tcp.port);
	dport = ntohs(ct->tuplehash[dir].tuple.dst.u.tcp.port);

	type="HDR";
	if (dataoff >= skb->len) {
		ret = NF_ACCEPT;
		goto _myexit;
	}
	datalen = skb->len - dataoff;

    if (dport == conf_port) {
		type="REQ";
		//request
		if (!ct_httprtt_info->timestamp) {
			ct_httprtt_info->timestamp = get_jiffies_64();
		}
	}
	else if (sport == conf_port) {
		type="RSP";
		//response
		//simulate packet drop
		//ct_httprtt_info->count++;
		//if (!(ct_httprtt_info->count % 3)) {
			//printk(KERN_ERR "RSP: " FORMAT " drop %d, data=[%s]\n", DATA, ct_httprtt_info->count, data);
			//return NF_DROP;
		//}

		if (!ct_httprtt_info->done && ct_httprtt_info->timestamp) {
			delta = get_jiffies_64() - ct_httprtt_info->timestamp;
			ct_httprtt_info->done = 1;
			statistic(delta);
		}
	}
_myexit:
	{
                char *dataptr = 0;
                char data[5] = {0,0,0,0,0};
		char *drop="";
		//simulate drop
		if(sport==conf_port && !th->syn && !th->fin && !th->rst && ct_httprtt_info->count<13){
			ct_httprtt_info->count++;
			if(th->psh || ct_httprtt_info->count%3){
				drop="(drop)";
//#define SIM_STOLEN
#ifdef SIM_STOLEN
				//use STOLEN style to simulate packets drop
				ret = NF_STOLEN;
				kfree_skb(skb);
#else
				//use DROP style to simulate packets drop
				ret = NF_DROP;
#endif
			}
		}
		if (dataoff < skb->len) {
                	dataptr=skb_header_pointer(skb, dataoff, 4, data);
	                if(dataptr!=&data[0]){
				memcpy(data, dataptr, 4);
			}
		}
		printk(KERN_ERR "%s:" FORMAT " data=[%s] %s\n", type, DATA, data, drop);
	}
	return ret;
}

static const struct nf_conntrack_expect_policy httprtt_exp_policy = {
    .max_expected	= 1,
};

static struct nf_conntrack_helper httprtt __read_mostly = {
	.me			= THIS_MODULE,
	.help			= help,
	.expect_policy		= &httprtt_exp_policy,
	.name			= "httprtt",
	.data_len		= sizeof(struct nf_ct_httprtt_master),
	.tuple.src.l3num	= AF_INET,
	.tuple.dst.protonum	= IPPROTO_TCP,
};

static void nf_conntrack_httprtt_fini(void)
{
	printk(KERN_ERR "nf_ct_httprtt: fini\n");
	remove_proc_entry("httprtt", init_net.proc_net);
	nf_conntrack_helper_unregister(&httprtt);
}

static void *m_start(struct seq_file *m, loff_t *pos)
__acquires(RCU)
{
    rcu_read_lock();
    if (!*pos)
        return SEQ_START_TOKEN;
    return NULL;
}

static void *m_next(struct seq_file *m, void *p, loff_t *pos)
{
    ++*pos;
	return NULL;
}

static void m_stop(struct seq_file *m, void *p)
__releases(RCU)
{
    rcu_read_unlock();
}

static int m_show(struct seq_file *m, void *p)
{
	seq_printf(m, "%d %d %d\n", atomic_read(&result_counter[0]), atomic_read(&result_counter[1]), atomic_read(&result_counter[2]));
	return 0;
}

static const struct seq_operations httprtt_seq_ops = {
	.start  = m_start,
	.next   = m_next,
	.stop   = m_stop,
	.show   = m_show,
};

static int httprtt_seq_open(struct inode *inode, struct file *file)
{
	return seq_open(file, &httprtt_seq_ops);
}

static const struct file_operations httprtt_seq_fops = {
	.owner	 = THIS_MODULE,
	.open	 = httprtt_seq_open,
	.read	 = seq_read,
	.llseek	 = seq_lseek,
	.release = seq_release,
};

static int __init nf_conntrack_httprtt_init(void)
{
	int ret = 0;
	struct proc_dir_entry *pde;

	printk(KERN_ERR "nf_ct_httprtt: init, HZ=%d\n", HZ);
	//httprtt.tuple.dst.u.tcp.port = cpu_to_be16(conf_port);
	ret = nf_conntrack_helper_register(&httprtt);
	if (ret) {
		printk(KERN_ERR "nf_ct_httprtt: failed to register");
		nf_conntrack_httprtt_fini();
		return ret;
	}

	pde = proc_create("httprtt", S_IRUGO,
			  init_net.proc_net, &httprtt_seq_fops);
	if (!pde)
		return -1;

	return 0;
}

module_init(nf_conntrack_httprtt_init);
module_exit(nf_conntrack_httprtt_fini);
