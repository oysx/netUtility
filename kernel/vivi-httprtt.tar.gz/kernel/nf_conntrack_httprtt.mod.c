#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

__visible struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0x1fc32c62, __VMLINUX_SYMBOL_STR(module_layout) },
	{ 0xafad493b, __VMLINUX_SYMBOL_STR(param_ops_ushort) },
	{ 0x8d2e268b, __VMLINUX_SYMBOL_STR(param_ops_ulong) },
	{ 0xbbf205bf, __VMLINUX_SYMBOL_STR(seq_release) },
	{ 0x9ca10237, __VMLINUX_SYMBOL_STR(seq_read) },
	{ 0x6916acf6, __VMLINUX_SYMBOL_STR(seq_lseek) },
	{ 0xa877ee10, __VMLINUX_SYMBOL_STR(proc_create_data) },
	{ 0xac52b96e, __VMLINUX_SYMBOL_STR(nf_conntrack_helper_register) },
	{ 0xfb95f05e, __VMLINUX_SYMBOL_STR(nf_conntrack_helper_unregister) },
	{ 0x12d54a2b, __VMLINUX_SYMBOL_STR(remove_proc_entry) },
	{ 0x62878c7b, __VMLINUX_SYMBOL_STR(init_net) },
	{ 0x7d11c268, __VMLINUX_SYMBOL_STR(jiffies) },
	{ 0x7f24de73, __VMLINUX_SYMBOL_STR(jiffies_to_usecs) },
	{ 0x27e1a049, __VMLINUX_SYMBOL_STR(printk) },
	{ 0xf0fdf6cb, __VMLINUX_SYMBOL_STR(__stack_chk_fail) },
	{ 0x7a5d4d79, __VMLINUX_SYMBOL_STR(skb_copy_bits) },
	{ 0xa05f372e, __VMLINUX_SYMBOL_STR(seq_printf) },
	{ 0x46b7c5f, __VMLINUX_SYMBOL_STR(seq_open) },
	{ 0xbdfb6dbb, __VMLINUX_SYMBOL_STR(__fentry__) },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=nf_conntrack";


MODULE_INFO(srcversion, "F8DF2FDCD7874F1B578179C");
